<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class tb_program extends Model
{
    protected $table = 'tb_programs';
    protected $fillable = [
        'Kas','Kebersihan','Keamanan','Kegiatan','Bencana',
    ];
    protected $primaryKey = 'id';
    use HasFactory;
}
