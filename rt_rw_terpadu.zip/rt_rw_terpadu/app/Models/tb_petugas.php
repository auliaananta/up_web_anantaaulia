<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class tb_petugas extends Model
{
    protected $table = 'tb_petugas';
    protected $fillable = [
        'Nama_Petugas','Email','Password','No_Telp',
    ];
    protected $primaryKey = 'id';
    use HasFactory;
}
