<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class tb_rt extends Model
{
    protected $table = 'tb_rt';
    protected $fillable = 
    [
        'Nama_Rt','Masa_Jabatan','No_Telp','Email',	
    ];
    protected $primaryKey = 'id';
    use HasFactory; 

}
