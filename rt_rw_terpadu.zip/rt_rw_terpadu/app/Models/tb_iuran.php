<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class tb_iuran extends Model
{
    protected $table = 'tb_iuran';
    protected $fillable = [
        'Tanggal_Update_Iuran','Nomisal_Iuran',
    ];
    protected $primaryKey = 'id';
    use HasFactory;
}
