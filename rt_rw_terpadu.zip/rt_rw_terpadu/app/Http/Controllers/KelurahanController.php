<?php

namespace App\Http\Controllers;

use App\Models\tb_Kelurahan;
use Illuminate\Http\Request;

class KelurahanController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data = tb_kelurahan::all();
        return view('kelurahan.index', compact('data'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('kelurahan.create');

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        tb_kelurahan::create([
            'Nama_Kelurahan' =>$request->Nama_Kelurahan,
            'Nama_Lurah' =>$request->Nama_Lurah,
            'Masa_Jabatan' =>$request->Masa_Jabatan,
            'No_Telp' =>$request->No_Telp,
            'Email' =>$request->Email,
        ]);

        return redirect('/kelurahan');

    }
    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $edit = tb_kelurahan::find($id);
        return view('kelurahan.edit', compact('edit'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $update = tb_Kelurahan::find($id);
        $update->Nama_Kelurahan = $request->Nama_Lurah;
        $update->Masa_Jabatan = $request->Masa_Jabatan;
        $update->No_Telp = $request->No_Telp;
        $update->Email = $request->Email;
        $update->save();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $delete = tb_kelurahan::find($id);        
        $delete->delete();
    
        return redirect('/kelurahan');
    }
}
