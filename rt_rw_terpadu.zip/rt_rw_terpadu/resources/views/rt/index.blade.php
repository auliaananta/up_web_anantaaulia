<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
</head>
<body>
	<thead>
		<tr>
			<td>Nama Rt</td>
			<td>Masa Jabatan</td>
			<td>No Telp</td>
			<td>Email</td>
		</tr>
	</thead>
	@foreach($data as $item)
	<tbody>
		<tr>
			<td> {{ $loop->iteration }} </td>
			<td> {{ $item->Nama_Rt }} </td>
			<td> {{ $item->Masa_Jabatan }} </td>
			<td> {{ $item->No_Telp }} </td>
			<td> {{ $item->Email }} </td>
		</tr>
	</tbody>
	@endforeach
</body>
</html>