<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
</head>
<body>
	<thead>
		<tr>
			<td>Nama Rt</td>
			<td>Masa Jabatan</td>
			<td>No Telp</td>
			<td>Email</td>
		</tr>
	</thead>
	<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<tbody>
		<tr>
			<td> <?php echo e($loop->iteration); ?> </td>
			<td> <?php echo e($item->Nama_Rt); ?> </td>
			<td> <?php echo e($item->Masa_Jabatan); ?> </td>
			<td> <?php echo e($item->No_Telp); ?> </td>
			<td> <?php echo e($item->Email); ?> </td>
		</tr>
	</tbody>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</body>
</html><?php /**PATH C:\xampp\htdocs\rt_rw_terpadu\resources\views/rt/index.blade.php ENDPATH**/ ?>