<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tb_user', function (Blueprint $table) {
            $table->id();
            $table->string('Name');
            $table->string('Email')->unique();
            $table->timestamp('email_verified_at')->nullable();
            $table->string('Password');
            $table->string('Jenis_Kelamin');
            $table->string('Tempat_Lahir');
            $table->string('Tanggal_Lahir');
            $table->string('Pekerjaan');
            $table->string('Penghasilan');
            $table->string('Kota');
            $table->string('Kecamatan');
            $table->string('Kelurahan');
            $table->string('Alamat');
            $table->string('No_Rumah');
            $table->string('Qr_Code');
            $table->rememberToken();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tb_user');
    }
}
